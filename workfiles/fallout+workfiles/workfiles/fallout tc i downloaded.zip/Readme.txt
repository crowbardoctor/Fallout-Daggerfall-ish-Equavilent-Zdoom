       Little Less Fallout/Doom Graphical (almost total) Conversion (alpha )
                    by  cyber@pinocchio2.com

The name says it all, it's nothing special, just a work
based on copy and paste.

The list of credits is very long, apart Fallout legacy
by Interplay, and id - valve - 3D Realms genius...of course,
i downloaded almost every doom's total conversions from:

http://www.doomwadstation.suhost.com/main/tc.html

and used in particular half life/doom total conversion, Star Wars/doom,
and Hacks-X. Then i download a lot of files from:

www.nma-fallout.com (also the little duke nukem/fallout)

and duke nukem/doom total conversion by:

Duke Nukem Doom!
 v3.0 - 6/27/00
By:Doug Kavendek

I didn't change doom's fonts into fallout's fonts and interface, so
if someone wants to do that... he will be welcome.
There are no new sounds, no new maps, no new type of gameplay, and
i tested it only with gldoom and zdoomgl, it looks fine and fun,
but it's not a masterpiece.
The "new" weapons are:
iron fists, double berettas, double nuke shotgun, chain gun,
and rocket rifle.
The "new" monsters are:
S-terminator, cyborgs used by mutie army ( sorry i don't have
Blood's plasma pak so no purple cultists of the Cathedral ;)
Mutie with shoulder shotgun (duke nukem overlord)
Mutie with chaingun  (duke nukem lunarlord)
Fire breathing deathclaw  (hexen? heretic?)
Small alien  (duke nukem add on)
Giant alien  (gargantua from half life)
Giant queen alien (duke nukem add on)
Giant mutie  (cyclop from duke)
Floating floater  (octobrain from duke)
Psichic floating mutie (duke)
psionic flying brain/skulls  (doom)
Powered armor mutie  (dark forces)
Big boss Master ( Fallout frm)

Installation: just unzip and put in your doom2 directory,
maybe after a back up of doom2.wad. It's not 
professional but everybody could do that.

Permissions:
You can't use it for commercial stuff of course, there are works of
other people and professional software houses.
I hope you like it